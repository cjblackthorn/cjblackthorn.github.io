BLACKTHORN FIELD NOTES — GPTZERO ARTICLE EXPORT
Prepared: 2026-11-02
Source: https://github.com/cjblackthorn/cjblackthorn.github.io/tree/main/_posts
Articles included: 13

CONTENTS
full_articles/
  Thirteen complete articles, each in its own UTF-8 plain-text file.
  Front matter and Markdown formatting were removed, preserving prose
  and section headings. These are ORIGINAL published texts, not rewrites.

gptzero_chunks/
  The same article prose in smaller parts of at most 9,000 characters,
  divided at paragraph boundaries for limited-size scanning plans.
  Each filename identifies its original article and part number.
  Scan every part to cover an entire long article; don't average scores
  as though they were reliable authorship probabilities.

manifest.csv
  Title, publication date, filename, characters, words, chunk count,
  and exact source Markdown URL.

NOTES
- These are copies for your personal editorial review.
- No articles were edited or republished as part of this export.
- GPTZero results are statistical estimates, not proof of authorship.
- The original published Markdown remains on the main branch.
